//Автор: Евсеев Михаил
public class DictionaryEntry {
    public String name;
    public String URL;
    public String nameRu;
    public String type;

    public DictionaryEntry(String name, String URL, String nameRu, String type) {
        this.name = name;
        this.URL = URL;
        this.nameRu = nameRu;
        this.type = type;
    }
}
